<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Questions extends CI_Controller {

	
	public function question1()
	{
		//checkSession();
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question1');
		$this->load->view('layout/footer');		
	}
	public function question2()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question2');
		$this->load->view('layout/footer');		
	}

	public function question3()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question3');
		$this->load->view('layout/footer');		
	}
	public function question4()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question4');
		$this->load->view('layout/footer');		
	}
	public function question5()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question5');
		$this->load->view('layout/footer');		
	}
	public function question6()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question6');
		$this->load->view('layout/footer');		
	}
	public function question7()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question7');
		$this->load->view('layout/footer');		
	}
	public function question8()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question8');
		$this->load->view('layout/footer');		
	}
	public function question9()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question9');
		$this->load->view('layout/footer');		
	}
	public function question10()
	{
		if(!$this->session->userdata('userID'))
			return redirect('home');
		$this->load->view('layout/header');
		$this->load->view('questions/question10');
		$this->load->view('layout/footer');		
	}


}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */
