<!--  <?php 
$conn = new mysqli('localhost','root','','test');
if($conn->connect_error)
{
	die("error:".$conn->connect_error);
}
$result = $conn->query("SELECT  marks, firstName,lastName, timetaken from user_answers2 WHERE marks = (SELECT MAX(marks) from user_answers2) ORDER BY timetaken ASC LIMIT 3;");
if($result->num_rows >0)
{
	?>
	   <div class="table-responsive">
                <table class="table table-lightborder">
                <thead>
                <tr>
                <th class="text-center">Rank</th>
                <th class="text-center">Full Name</th>
                <th class="text-center">Marks Obtained</th>
                <th class="text-center">Time Taken</th>
                </tr>
                </thead>
	
	<?php
    $counter = 1;
	while($row = $result->fetch_assoc())
	{
			?>
			<tbody>
                <tr>
                <td class="text-center"><?php echo $counter; 
                $counter = $counter + 1;
                ?></td>
                <td class="nowrap text-center"><?php echo $row['firstName']." ".$row['lastName']; ?></td>
         		<td class="text-center"><?php echo $row['marks']; ?></td>
         		<td class="text-center"><?php echo $row['timetaken']." Seconds"; ?></td>
                </tr>

			<?php
	}
	?></tbody></table></div><?php
}

 ?> -->


                
                