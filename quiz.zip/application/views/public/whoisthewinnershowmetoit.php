<div class="all-wrapper with-side-panel solid-bg-all">
<div class="layout-w">
          <div class="content-w">
              <!--------------------
END - Breadcrumbs
-------------------->
              <div class="content-panel-toggler"><i class="os-icon os-icon-grid-squares-22"></i><span>Sidebar</span></div>
              <div class="content-i">
                <div class="content-box">
              
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="element-wrapper">
                                <h6 class="element-header">Winner Of Quiz</h6>
                                <div id = "winner"></div>
                            </div>
                        </div>
                    </div>

                </div>
                <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.js"></script>
             <script type="text/javascript">
  $(document).ready(function() {
    setInterval(function(){
        $('#winner').load("<?php echo base_url();?>winner")

  },2);
  });
</script>