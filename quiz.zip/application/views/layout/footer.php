
</div>
</div>
</div>
<div class="display-type"></div>
</div>
<script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
</body>

</html>
