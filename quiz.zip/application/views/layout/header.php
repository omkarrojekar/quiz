<!DOCTYPE html>
<html>

<head>
  <title>Quiz</title>
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="<?php echo base_url();?>assets/apple-touch-icon.png" rel="apple-touch-icon">
    <link href="<?php echo base_url();?>assets/bower_components/select2/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/maince5a.css?version=4.4.1" rel="stylesheet">
      <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
</head>
