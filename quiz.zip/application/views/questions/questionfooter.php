   <!--------------------
                START - Sidebar
                -------------------->
                <div class="content-panel">
                    <div class="content-panel-close"><i class="os-icon os-icon-close"></i></div>


                    <div class="element-wrapper">
                        <h6 class="element-header">Live Updates</h6>
                        <div class="element-box">
                <div class="table-responsive">
                <table class="table table-lightborder">
                <thead>
                <tr>
                <th>User</th>
                <th class="text-right">Attempting Answers</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                <tr>
                <td class="nowrap">John Mayers</td>
                <td class="text-center">5</td>
                </tr>
                </tbody>
                </table>
                </div>
                </div>
                    </div>
                    <!--------------------
                END - Team Members
                -------------------->
                </div>
                <!--------------------
                END - Sidebar
                -------------------->