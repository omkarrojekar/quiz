<body id="dashboard-back" class="menu-position-side menu-side-left  with-content-panel">
<div class="all-wrapper with-side-panel solid-bg-all">
<div class="layout-w">
          <div class="content-w">
              <!--------------------
END - Breadcrumbs
-------------------->
              <div class="content-panel-toggler"><i class="os-icon os-icon-grid-squares-22"></i><span>Sidebar</span></div>
              <div class="content-i">
                <div class="content-box">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="element-wrapper">
                                <h6 class="element-header">Quiz</h6>
                                <form id="quiz-form" class="element-box" action="<?php echo base_url();?>home/storeanswers" method="POST">
      <label class="labeltext">2. Cancer may cause when...</label>      
      <label class="customradio"><span class="radiotextsty">The diploid number of chromosomes become defective </span>
        <input type="radio" name="q2" value="A">
        <span class="checkmark"></span>
      </label>
      <label class="customradio"><span class="radiotextsty">Changes occur in genes controlling cell divisions </span>
        <input type="radio" name="q2" value="B">
        <span class="checkmark"></span>
      </label>
      <label class="customradio"><span class="radiotextsty">When the loci start to change in chromosomes </span>
        <input type="radio" name="q2" value="C">
        <span class="checkmark"></span>
      </label>
      <label class="customradio"><span class="radiotextsty">All of the above</span>
        <input type="radio" name="q2" value="D">
        <span class="checkmark"></span>
      </label>
      <div class="form-buttons-w">
            <input type="hidden" name="question" value="question2">
            <button class="btn btn-primary" name="storeprogress" type="submit">Next</button>
            </div>
    </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!--------------------
                START - Sidebar
                -------------------->
                <div class="content-panel">
                    <?php $this->load->view('questions/list.php'); ?>
                </div>
                <!--------------------
                END - Sidebar
                -------------------->
</body>